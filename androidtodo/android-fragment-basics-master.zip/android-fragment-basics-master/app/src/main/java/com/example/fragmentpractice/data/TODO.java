package com.codepath.fragmentpractice.data;

public class TODO {

  public static String[] todoMenu = {
      "Submit DMA Code",
      "Production Project"
  };

  public static String[] todoDetails = {
      "Submit DMA project by june 17, 2020.",
      "Production project report submission on june 20, 2020",
  };
}
